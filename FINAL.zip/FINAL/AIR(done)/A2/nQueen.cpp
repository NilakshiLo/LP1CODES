#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

ll rowHash[501], mat[501][501], rdValue[501][501], ldValue[501][501], rdHash[501], ldHash[501];

void printMat(ll n){
    for(ll i=0; i<n; i++){
        for(ll j=0; j<n; j++){
            cout<<mat[i][j]<<" ";
        }cout<<"\n";
    }
}

bool solveBT(ll n, ll c){
    if(c>=n) return true;
    for(ll r=0; r<n; r++){
        if(!rowHash[r] && !rdHash[r+c] && !ldHash[r-c+n-1]){
           mat[r][c] = rowHash[r] =rdHash[r+c] = ldHash[r-c+n-1]=1;
           if(solveBT(n,c+1)) return true;
           mat[r][c] = rowHash[r] =rdHash[r+c] = ldHash[r-c+n-1]=0;
        }
    }
    return false;
}

bool solveBB(ll n, ll c){
    if(c>=n) return true;
    for(ll r=0; r<n; r++){
        if(!rowHash[r] && !rdHash[rdValue[r][c]] && !ldHash[ldValue[r][c]]){
           mat[r][c] = rowHash[r] =rdHash[rdValue[r][c]] = ldHash[ldValue[r][c]]=1;
           if(solveBB(n,c+1)) return true;
           mat[r][c] = rowHash[r] =rdHash[rdValue[r][c]] = ldHash[ldValue[r][c]]=0;
        }
    }
    return false;
}


int main(){
    ll n; cin>>n;
    
    for(ll i=0; i<n; i++){
        for(ll j=0; j<n; j++){
            rdValue[i][j] = i+j;
            ldValue[i][j] = i-j+n-1;
        }
    }
    
    memset(mat,0,sizeof(mat));
    memset(rowHash,0,sizeof(rowHash));
    memset(rdHash,0,sizeof(rdHash));
    memset(ldHash,0,sizeof(ldHash));
 
    if(!solveBT(n,0)) cout<<"Not Possible!!!\n";
    else printMat(n);
    cout<<"\n\n\n";
    
    memset(mat,0,sizeof(mat));
    memset(rowHash,0,sizeof(rowHash));
    memset(rdHash,0,sizeof(rdHash));
    memset(ldHash,0,sizeof(ldHash));
 
    if(!solveBB(n,0)) cout<<"Not Possible!!!\n";
    else printMat(n);
return 0;
}
