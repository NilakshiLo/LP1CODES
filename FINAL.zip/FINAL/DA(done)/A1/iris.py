!curl https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data --output iris.csv

import pandas as pd

columns=["sepal-length","sepal-width","petal-length","petal-width","class"]

data = pd.read_csv("iris.csv", names=columns)

data.head()

data.dtypes

data.describe()

mean = data.mean(axis=0)
mini = data.min(axis=0)
maxi = data.max(axis=0)
std = data.std(axis=0)
var = data.var(axis=0)
rangeList = []
rangeList[:-1:]=maxi[:-1:]-mini[:-1:]

print(mean)
print(mini)
print(maxi)
print(std)
print(var)
print(rangeList)

histogram = data.hist(bins=50)

boxplot = data.boxplot(column=["sepal-width"])
