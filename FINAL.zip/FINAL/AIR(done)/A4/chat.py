from nltk.chat.util import Chat, reflections

pairs = [
    [
        r"my name is (.*)",
        ["Hello %1, how are you?"]
    ],
    [
        r"hi|hey|hello(.*)",
        ["Hello", "Hey there",]
    ],
    [
        r"quit",
        ["Signing out, see you again ^_^",]
    ],
]

def chatbot():
  print("Booting up...\n Hey, I am simple Chat Bot")
  chat = Chat(pairs, reflections)
  chat.converse()
  
if __name__ == "__main__" : 
  chatbot()
  
/*
sudo jupyter notebook --allow-root
*/
