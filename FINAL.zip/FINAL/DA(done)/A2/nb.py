import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix
data = pd.read_csv("diabetes.csv")

columns = data.columns

columns = [col_name for col_name in columns if not col_name=="Outcome"]

X = data.drop(["Outcome"], axis=1)
Y = data["Outcome"]

scaler = MinMaxScaler()
X[columns] = scaler.fit_transform(X)

train_X, test_X, train_Y, test_Y = train_test_split(X,Y,test_size=0.3)

model = GaussianNB()
model.fit(train_X, train_Y)

predictions = model.predict(test_X)

model.score(test_X, test_Y)

confusion_matrix(test_Y, predictions)
