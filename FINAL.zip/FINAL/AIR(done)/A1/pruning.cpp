#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

ll a[5001];
ll MINI = -1000;
ll MAXI = 1000;

ll pruning(ll depth, ll node, ll alpha,ll beta,bool flag, ll leaf){
    if(depth==leaf) return a[node];
    if(flag){
        ll best = MINI;
        for(ll i=0; i<2; i++){
            ll val = pruning(depth+1,node*2+i,alpha,beta,0,leaf);
            best = max(best, val);
            alpha = max(alpha, best);
        }
        return best;
    }
    else{
        ll best = MAXI;
        for(ll i=0; i<2; i++){
            ll val = pruning(depth+1,node*2+i,alpha,beta,1,leaf);
            best = min(best,val);
            beta = min(beta,best);
        }
        return best;
    }
}

int main(){
    ll n; cin>>n;
    for(ll i=0; i<n; i++) cin>>a[i];
    
    ll leaf = log2(n);
    if(pow(2,leaf)<n) leaf++;
    cout<<pruning(0,0,MINI,MAXI,1,leaf)<<"\n";
return 0;
}
