#include<bits/stdc++.h>
#include<chrono>
#include "omp.h"

using namespace std;
using namespace std::chrono;

void initArr(int arr1[],int arr2[], int n){
    for(int i=0; i<n; i++){
        arr1[i] =arr2[i]= n-i;
    }
}

void printArr(int arr[], int n){
    for(int i=0; i<n; i++){
        cout<<arr[i]<<" ";
    }
    cout<<"\n";
}

void serialBubble(int arr[], int n){
    time_point<system_clock> start, end;
    start = system_clock::now();
    
    for(int i=0; i<(n-1); i++){
        for(int j=0; j<(n-1); j++){
            if(arr[j]>arr[j+1]){
                int temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
    
    end = system_clock::now();
    duration<double> time = end-start;
    
    //printArr(arr,n);
    cout<<"Serial Execution time taken : "<<time.count()*1000<<"\n";
}

void parallelBubble(int arr[], int n){
    time_point<system_clock> start, end;
    start = system_clock::now();
    
    omp_set_num_threads(2);
    
    int first=0;
    int t=2;
    while(t--){
        for(int i=0; i<(n-1); i++){
            first = (i+1)%2;
            #pragma omp parallel for default(none), shared(arr, first, n)
            for(int j=first; j<(n-1); j+=2){
                if(arr[j]>arr[j+1]){
                    //cout<<arr[j]<<" "<<arr[j+1]<<" "<<j<<"\n";
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
            }
        }
    }
    
    end = system_clock::now();
    duration<double> time= end-start;
    
   // printArr(arr,n);
    cout<<"Parallel Execution time : "<<time.count()*1000<<"\n";
}

int main(){
    int n; cin>>n;
    int arr1[n], arr2[n];
    initArr(arr1, arr2,n);
    printArr(arr1, n);
    
    serialBubble(arr1,n);
    parallelBubble(arr2,n);
    return 0;
}
