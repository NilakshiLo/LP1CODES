#include<bits/stdc++.h>
#define mp make_pair
#define pb push_back
using namespace std;
typedef long long ll;
int main(){
	vector<ll>fi, src, u;
	map<vector<ll>, ll>ans, visited, step;
	cout<<"NOTE: ENTER -1 FOR EMPTY CELL\n";
	cout<<"Enter initial state\n";
	for(ll i=0;i<9;i++){ll x;cin>>x;src.pb(x);}
	cout<<"Enter final state\n";
	for(ll i=0;i<9;i++){ll x;cin>>x;fi.pb(x);}
	ans.insert(mp(fi,1));
	queue<vector<ll> >q;
	visited[src]=1; step[src]=0;
	q.push(src);
	bool found=0;
	while(!q.empty()){
		u = q.front();
		q.pop();
		if(ans.find(u)!=ans.end()){found=1;break;}
		ll mat[3][3], k=0;
		for(ll i=0;i<3;i++){
			for(ll j=0;j<3;j++){
				mat[i][j] = u[k++];
			}
		}
		bool flag=0;
		vector<ll>up,down,left,right;
		for(ll i=0;i<3;i++){
			for(ll j=0;j<3;j++){
				if(mat[i][j] == -1){
					if(i!=0){
						swap(mat[i][j], mat[i-1][j]);
						for(ll k=0;k<3;k++) for(ll l=0;l<3;l++) up.pb(mat[k][l]);
						swap(mat[i][j], mat[i-1][j]);
					}
					if(i!=2){
						swap(mat[i][j], mat[i+1][j]);
						for(ll k=0;k<3;k++) for(ll l=0;l<3;l++) down.pb(mat[k][l]);
						swap(mat[i][j], mat[i+1][j]);
					}
					if(j!=0){
						swap(mat[i][j], mat[i][j-1]);
						for(ll k=0;k<3;k++) for(ll l=0;l<3;l++) left.pb(mat[k][l]);
						swap(mat[i][j], mat[i][j-1]);
					}
					if(j!=2){
						swap(mat[i][j], mat[i][j+1]);
						for(ll k=0;k<3;k++) for(ll l=0;l<3;l++) right.pb(mat[k][l]);
						swap(mat[i][j], mat[i][j+1]);
					}
					flag=1;
					break;
				}
			}
			if(flag)break;
		}
		if(!up.empty() && !visited[up]){
			step[up] = step[u]+1;
			visited[up]=1;
			q.push(up);
		}
		if(!down.empty() && !visited[down]){
			step[down] = step[u]+1;
			visited[down]=1;
			q.push(down);
		}
		if(!right.empty() && !visited[right]){
			step[right] = step[u]+1;
			visited[right]=1;
			q.push(right);
		}
		if(!left.empty() && !visited[left]){
			step[left] = step[u]+1;
			visited[left]=1;
			q.push(left);
		}
	}
	if(found)cout<<step[fi]<<"\n";
	else cout<<"Not found\n";
	return 0;
}
