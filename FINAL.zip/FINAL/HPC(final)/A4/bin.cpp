#include<bits/stdc++.h>
#include<mpi.h>
using namespace std;

void initArr(int a[], int n){
    for(int i=0; i<n; i++){
        a[i]=i+1;
    }
}
void printArr(int a[], int n){
    for(int i=0; i<n; i++){
        cout<<a[i]<<" ";
    }
    cout<<"\n";
}
void bSearch(int arr[], int s, int e, int key, int rank){
    while(s<=e){
        int mid = (s+e)/2;
        if(arr[mid]==key){
            cout<<"Element is found by processor "<<rank<<"\n"; return;
        }
        if(arr[mid]<key) s = mid+1;
        else e = mid-1;
    }
}

int main(int argc, char **argv){
    int n; /*cout<<"Enter the size of array : ";
    cin>>n;*/
    n = 10;
    
    int a[n];
    initArr(a,n);
    printArr(a,n);
    
    //cout<<"Enter the key to search :";
    int key=10;// cin>>key;
    if(key<=0 || key>n) return 0;
    
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Comm_rank(MPI_COMM_WORLD,&size);
    
    cout<<"Processor rank : "<<rank<<"\nSize : "<<size<<"\n";
    int block=2;
    int blockSize = n/block;
    
    if(rank==0){
        double start = MPI_Wtime();
        bSearch(a, rank*blockSize, (((rank+1)*blockSize)-1), key, rank );
        double end = MPI_Wtime();
        cout<<"Exectuion time of Processor "<<rank<<" : "<<(end-start)*1000<<"\n";
    }
    else if(rank==1){
        double start = MPI_Wtime();
        bSearch(a, rank*blockSize, (((rank+1)*blockSize)-1), key, rank );
        double end = MPI_Wtime();
        cout<<"Exectuion time of Processor "<<rank<<" : "<<(end-start)*1000<<"\n";
    }
    else if(rank==2){
        double start = MPI_Wtime();
        bSearch(a, rank*blockSize, (((rank+1)*blockSize)-1), key, rank );
        double end = MPI_Wtime();
        cout<<"Exectuion time of Processor "<<rank<<" : "<<(end-start)*1000<<"\n";
    }
    
    MPI_Finalize();
return 0;
}

/*
nilakshirocks@NilakshiRocks:~/Documents/BE/NILAKSHIROCKS/FINAL/HPC/A4$ mpiCC bin.cpp
nilakshirocks@NilakshiRocks:~/Documents/BE/NILAKSHIROCKS/FINAL/HPC/A4$ mpirun -np 2 ./a.out

*/
