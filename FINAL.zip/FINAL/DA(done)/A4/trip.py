import pandas as pd
import seaborn as sn

from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler

data = pd.read_csv("store.csv")

data.isnull().any()
data = data.fillna(method="ffill")
data.isnull().any()

data.shape
data.head()
print(data.columns)

data = data.drop(["Start station"], axis=1)
data = data.drop(["End station"], axis=1)
data = data.drop(["Start date"], axis=1)
data = data.drop(["End date"], axis=1)


le = LabelEncoder()
le.fit(data["Bike number"])
data["Bike number"] = le.transform(data["Bike number"])

data.head()
le = LabelEncoder()
le.fit(data["Member type"])
data["Member type"] = le.transform(data["Member type"])

X = data.iloc[:,:-1].values
Y = data.iloc[:,-1].values
print(X)
print(Y)

sc_x = StandardScaler()
X = sc_x.fit_transform(X)

x_train, x_test, y_train, y_test = train_test_split(X,Y,test_size=0.25, random_state=0)

classifier = GaussianNB()
classifier.fit(x_train, y_train)

predicted = classifier.predict(x_test)
cm = confusion_matrix(y_test, predicted)
print(cm)

sn.heatmap(cm)

acc = (cm[0][0]+cm[1][1])/(cm[0][0]+cm[0][1]+cm[1][0]+cm[1][1])
print(acc)
